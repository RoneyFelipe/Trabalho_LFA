void main()
{
   a = 10;
   b = 3;
   while (a){
     c = (a+b*2;
     a = a - 1;
     b = b*b;
   }
}
