int f()
{
  a = 10;

  b = 3;
}
void main()
{
   a = 10;
   b = 3;
   while (a){
     c = (a-b)*2;
     a = a + 1 + (b * (c + 1) / d);
     b = b*b;
   }
   a = 10;
   while (b)
     a = 10;
   a = 10;
}
